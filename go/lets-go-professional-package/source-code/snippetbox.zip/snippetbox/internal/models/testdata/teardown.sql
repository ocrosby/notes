DROP TABLE users;

DROP TABLE snippets;